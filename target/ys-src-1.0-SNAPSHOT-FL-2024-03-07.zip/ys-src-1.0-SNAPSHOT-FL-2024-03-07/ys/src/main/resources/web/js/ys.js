function (wgt, dataValue) {
	//write your logic here
}